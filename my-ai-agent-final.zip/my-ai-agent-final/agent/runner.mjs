import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const exec = promisify(execFile);
const root = process.cwd();
const task = (process.env.TASK || '').trim();
const apiKey = (process.env.GEMINI_API_KEY || '').trim();
const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const maxIterations = 7;
const report = [];

const ignored = new Set(['.git', 'node_modules', '.next', 'dist', 'build', 'coverage']);

function safePath(p) {
  const normalized = path.normalize(p || '').replace(/^([/\\])+/, '');
  const full = path.resolve(root, normalized);
  if (full !== root && !full.startsWith(root + path.sep)) throw new Error(`Unsafe path: ${p}`);
  if (normalized.split(path.sep).includes('.git')) throw new Error('Git internals are not editable by the agent');
  return full;
}

async function listFiles(dir = '.', depth = 3, prefix = '') {
  if (depth < 0) return [];
  const full = safePath(dir);
  const entries = await fs.readdir(full, { withFileTypes: true });
  const out = [];
  for (const e of entries.sort((a,b) => a.name.localeCompare(b.name))) {
    if (ignored.has(e.name)) continue;
    const rel = prefix ? `${prefix}/${e.name}` : e.name;
    if (e.isDirectory()) out.push(...await listFiles(path.join(dir, e.name), depth - 1, rel));
    else out.push(rel);
  }
  return out;
}

async function readFile(p) {
  const full = safePath(p);
  const stat = await fs.stat(full);
  if (stat.size > 120000) return `[file too large: ${stat.size} bytes]`;
  return fs.readFile(full, 'utf8');
}

function commandAllowed(command) {
  if (!command || command.length > 500) return false;
  if (/[;&|`<>$(){}]/.test(command)) return false;
  if (/\b(rm|rmdir|del|format|shutdown|reboot|sudo|chmod|chown|mkfs|dd)\b/i.test(command)) return false;
  const first = command.trim().split(/\s+/)[0];
  const allowed = new Set(['npm','npx','node','python','python3','pytest','go','cargo','git','ls','find','pwd']);
  return allowed.has(first);
}

async function runCommand(command) {
  if (!commandAllowed(command)) throw new Error(`Command blocked by safety policy: ${command}`);
  const { stdout, stderr } = await exec('bash', ['-lc', command], { cwd: root, timeout: 120000, maxBuffer: 500000 });
  return `${stdout}${stderr ? `\n[stderr]\n${stderr}` : ''}`.slice(0, 30000);
}

async function fetchUrl(url) {
  const u = new URL(url);
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Only HTTP/HTTPS URLs are allowed');
  const res = await fetch(u, { headers: { 'User-Agent': 'My-AI-Agent/1.0' }, redirect: 'follow' });
  const text = await res.text();
  return `HTTP ${res.status}\n${text.slice(0, 30000)}`;
}

async function snapshot() {
  const files = await listFiles('.', 3);
  const selected = files.filter(f => /\.(js|mjs|cjs|ts|tsx|jsx|json|html|css|md|yml|yaml|py|go|rs|java|kt|swift|dart|php)$/i.test(f)).slice(0, 80);
  const contents = [];
  for (const f of selected) {
    try { contents.push(`\n--- ${f} ---\n${await readFile(f)}`); } catch {}
  }
  return { files, contents: contents.join('\n').slice(0, 120000) };
}

function extractJson(text) {
  const fenced = text.match(/```json\s*([\s\S]*?)```/i);
  const raw = (fenced ? fenced[1] : text).trim();
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('Model did not return JSON');
  return JSON.parse(raw.slice(start, end + 1));
}

async function askModel(context) {
  const system = `You are My AI Agent, an autonomous software engineering agent working inside a GitHub repository.\nReturn ONLY valid JSON with this shape: {"message":"short status","actions":[...]}.\nAllowed actions:\n- {"type":"read_file","path":"..."}\n- {"type":"write_file","path":"...","content":"..."}\n- {"type":"append_file","path":"...","content":"..."}\n- {"type":"delete_file","path":"..."}\n- {"type":"run","command":"..."}\n- {"type":"fetch_url","url":"https://..."}\n- {"type":"finish","message":"..."}\nUse at most 5 actions per turn. Never edit .git. Never request secrets. Commands must be simple safe developer commands such as npm install, npm test, npm run build, node ..., python ..., pytest, go test, cargo test, git status, git diff. Do not use shell chaining, redirection, sudo, rm, chmod, curl|sh, or destructive commands. If the task is already complete, use finish.\nWork iteratively: inspect before changing; after changes run relevant checks; if a check fails, fix it. The user expects the agent to actually execute the task, not merely explain how.`;
  const prompt = `${system}\n\nUSER TASK:\n${task}\n\nCURRENT REPOSITORY SNAPSHOT:\n${JSON.stringify(context)}`;
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0.15, responseMimeType: 'application/json' } }) });
  const data = await res.json();
  if (!res.ok) throw new Error(`Gemini API ${res.status}: ${JSON.stringify(data).slice(0, 2000)}`);
  const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || '';
  return extractJson(text);
}

async function executeAction(a) {
  switch (a.type) {
    case 'read_file': return { type: a.type, path: a.path, result: await readFile(a.path) };
    case 'write_file': {
      const full = safePath(a.path); await fs.mkdir(path.dirname(full), { recursive: true }); await fs.writeFile(full, a.content ?? '', 'utf8');
      return { type: a.type, path: a.path, result: 'written' };
    }
    case 'append_file': {
      const full = safePath(a.path); await fs.mkdir(path.dirname(full), { recursive: true }); await fs.appendFile(full, a.content ?? '', 'utf8');
      return { type: a.type, path: a.path, result: 'appended' };
    }
    case 'delete_file': {
      const full = safePath(a.path); await fs.rm(full, { force: true }); return { type: a.type, path: a.path, result: 'deleted' };
    }
    case 'run': return { type: a.type, command: a.command, result: await runCommand(a.command) };
    case 'fetch_url': return { type: a.type, url: a.url, result: await fetchUrl(a.url) };
    case 'finish': return { type: 'finish', result: a.message || 'Finished' };
    default: throw new Error(`Unknown action: ${a.type}`);
  }
}

async function commitIfChanged() {
  const status = await runCommand('git status --short');
  if (!status.trim()) return 'No changes to commit.';
  await runCommand('git config user.name My-AI-Agent');
  await runCommand('git config user.email my-ai-agent@users.noreply.github.com');
  await runCommand('git add -A');
  const message = `agent: ${task.replace(/\s+/g, ' ').slice(0, 70)}`;
  await runCommand(`git commit -m "${message.replace(/"/g, '')}"`);
  await runCommand('git push');
  return 'Changes committed and pushed.';
}

async function main() {
  if (!task) throw new Error('No task supplied.');
  report.push('# 🤖 My AI Agent Report', '', `**Task:** ${task}`, '', `**Model:** ${apiKey ? model : 'Demo/diagnostic mode (GEMINI_API_KEY missing)'}`, '');

  if (!apiKey) {
    report.push('## Status', 'The agent runner is installed and executable, but AI planning is disabled because `GEMINI_API_KEY` is not configured.', '', 'Add the key as a GitHub Actions repository secret named `GEMINI_API_KEY` to enable autonomous AI execution.');
    await fs.writeFile('agent-report.md', report.join('\n'), 'utf8');
    return;
  }

  let finalMessage = '';
  for (let i = 1; i <= maxIterations; i++) {
    const ctx = await snapshot();
    const plan = await askModel(ctx);
    report.push(`## Turn ${i}`, plan.message || '');
    const actions = Array.isArray(plan.actions) ? plan.actions.slice(0, 5) : [];
    for (const action of actions) {
      try {
        const result = await executeAction(action);
        const compact = typeof result.result === 'string' ? result.result.slice(0, 3000) : JSON.stringify(result.result).slice(0, 3000);
        report.push(`- **${action.type}** ${action.path || action.command || action.url || ''}`, '```text', compact, '```');
        if (result.type === 'finish') { finalMessage = result.result; break; }
      } catch (e) {
        report.push(`- ❌ **${action.type} failed:** ${e.message}`);
      }
    }
    if (finalMessage) break;
  }
  if (!finalMessage) finalMessage = 'The agent reached its iteration limit. Review the report and run the task again if needed.';
  report.push('', `## Result\n${finalMessage}`);
  try {
    const commit = await commitIfChanged();
    report.push('', `**Git:** ${commit}`);
  } catch (e) {
    report.push('', `**Git:** ${e.message}`);
  }
  await fs.writeFile('agent-report.md', report.join('\n'), 'utf8');
}

main().catch(async e => {
  report.push('', `## ❌ Agent error\n${e.stack || e.message}`);
  await fs.writeFile('agent-report.md', report.join('\n'), 'utf8').catch(() => {});
  console.error(e);
  process.exitCode = 1;
});
